#ifndef PAYMENTMETHOD_H
#define PAYMENTMETHOD_H

enum class PaymentMethod {
	ACCOUNTBALANCE = 0, CREDIT = 1, DEBIT = 2
};

#endif // !PAYMENTMETHOD_H
